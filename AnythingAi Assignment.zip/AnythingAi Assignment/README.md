# AnythingAI – Binance Futures Trading Bot (Testnet)

## 📌 Overview
This project is a command-line based Binance Futures Trading Bot built using Python.
It connects securely to the Binance Testnet environment and allows users to place
MARKET and LIMIT orders using terminal commands.

The project is designed with a clean and modular structure to demonstrate
good software engineering practices such as separation of concerns,
input validation, error handling, and logging.

---

## ⚙️ Features
- Uses Binance Futures Testnet (no real money involved)
- Secure API key handling using `.env` file
- Command-line interface (CLI)
- Supports MARKET and LIMIT orders
- Input validation before API calls
- Detailed logging of requests, responses, and errors

---

## 🗂️ Project Structure

1

## 🔐 Environment Setup
Create a `.env` file in the project root and add your Binance Testnet credentials:

BINANCE_API_KEY=your_testnet_api_key  
BINANCE_API_SECRET=your_testnet_secret_key

⚠️ The `.env` file should NOT be shared or uploaded.
👉 This shows security awareness.



## 📦 Installation
Install the required Python packages:

pip install -r requirements.txt
👉 This shows your project is reproducible.



## ▶️ How to Run

MARKET Order:
python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.01

LIMIT Order:
python cli.py --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.01 --price 30000
👉 This proves your project actually works.

## Note on Binance Futures Testnet Access

Binance Futures Testnet (https://testnet.binancefuture.com) redirects to demo.binance.com
in some regions (including India), which prevents API key creation for Futures endpoints.

This application is implemented using correct Binance USDT-M Futures logic, CLI argument
parsing, request signing, and order structure. However, live testnet order execution
may fail due to regional UI restrictions, not due to application logic.


