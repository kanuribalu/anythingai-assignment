from logging_config import setup_logger

logger = setup_logger()


def validate_order(symbol, quantity, order_type, price):
    """
    Validates order inputs before sending to Binance
    """
    if not symbol.endswith("USDT"):
        raise ValueError("Only USDT pairs are supported")

    if quantity <= 0:
        raise ValueError("Quantity must be greater than zero")

    if order_type == "LIMIT" and price is None:
        raise ValueError("Price is required for LIMIT orders")


def place_order(client, symbol, side, order_type, quantity, price=None):
    """
    Places a futures order on Binance Testnet
    """

    # Validate inputs
    validate_order(symbol, quantity, order_type, price)

    # Prepare order parameters
    params = {
        "symbol": symbol,
        "side": side,
        "type": order_type,
        "quantity": quantity
    }

    if order_type == "LIMIT":
        params["price"] = price
        params["timeInForce"] = "GTC"

    logger.info(f"SENT ORDER: {params}")

    try:
        response = client.futures_create_order(**params)
        logger.info(f"RECEIVED RESPONSE: {response}")
        return response

    except Exception as error:
        logger.error(f"ORDER FAILED: {error}")
        return None