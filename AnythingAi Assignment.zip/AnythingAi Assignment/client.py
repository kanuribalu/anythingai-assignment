import os
from binance.client import Client
from dotenv import load_dotenv


def get_authenticated_client():
    """
    Initializes and returns an authenticated Binance Futures Testnet client.

    This function:
    - Loads API credentials from a .env file
    - Validates the presence of API keys
    - Creates a secure client connected to Binance Testnet

    Returns:
        Client: Authenticated Binance client instance
    """

    # Load environment variables from .env file
    load_dotenv()

    # Fetch API credentials securely
    api_key = os.getenv("BINANCE_API_KEY")
    api_secret = os.getenv("BINANCE_API_SECRET")

    # Validate credentials
    if not api_key or not api_secret:
        raise ValueError(
            "Missing API credentials. Please verify your .env file."
        )

    # Initialize Binance client in Testnet mode
    client = Client(
        api_key=api_key,
        api_secret=api_secret,
        testnet=True
    )

    return client