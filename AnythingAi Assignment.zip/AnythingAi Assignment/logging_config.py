import logging

def setup_logger():
    """
    This function sets up logging configuration
    and returns a logger object for the trading bot.
    """
    logging.basicConfig(
        filename="trading.log", #log file name
        level=logging.INFO,     #log INFO and above
        format="%(asctime)s - %(levelname)s - %(message)s"
    )
    logger= logging.getLogger("TradingBot")
    return logger